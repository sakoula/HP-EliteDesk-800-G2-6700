HPBIOSUPDREC and HPQ Password
========================= 

HPBIOSUPDREC.exe - A utility to locally update or restore the system BIOS on 
                   individual PCs using the Microsoft Windows operating system.
               
HPBIOSUPDREC64.exe - 64-bit version of HPBIOSUPDREC.EXE

HPQ Password Utility - HPQPswd is a utility for saving a BIOS Setup Password to 
                       an encrypted file. This file is provided to HP BIOS update 
                       utilities for automated scripting, to avoid user prompting.

The BIOS update process can also be done from a USB flash media device by 
copying the files from this folder to the USB drive and executing HPBIOSUPDREC.exe
or HPBIOSUPDREC64.exe from the device in Microsoft Windows.

This utility will also copy the BIOS files to a USB storage device for use in
updating the BIOS in the BIOS Setup (F10) application. 


Files included in this folder:

HPBIOSUPDREC.exe
HPBIOSUPDREC64.exe
HPBIOSUPDREC.txt
HPQPswd.exe
HpqPswd64.exe
HpqPswd.txt
Readme.txt (this file)
xxx_xxxx.bin (BIOS image file)


Copyright (c) 2016 HP Development Company, L.P.

Product names mentioned herein may be trademarks and/or registered trademarks 
of their respective companies.
