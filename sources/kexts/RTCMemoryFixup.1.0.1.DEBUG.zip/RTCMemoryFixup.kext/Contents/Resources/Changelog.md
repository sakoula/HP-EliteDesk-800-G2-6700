RTCMemoryFixup Changelog
============================
#### v1.0.0
- Initial release

#### v1.0.1
- Bug fix: prevent kext unloading 
